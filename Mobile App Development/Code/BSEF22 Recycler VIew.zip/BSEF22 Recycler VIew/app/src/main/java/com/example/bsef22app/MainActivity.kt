package com.example.bsef22app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        recyclerView.adapter = UserAdapter(loadUsers()){ user: User ->
            Log.d("haris", "user " + user.name + " pressed")
        }
        recyclerView.layoutManager = GridLayoutManager(this, 2)




    }

    private fun loadUsers(): List<User> {
        // In a real app, you might load from database or network
        return listOf(
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com")
        )
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("haris", "on Restart")
    }

    override fun onStart() {
        super.onStart()

        Log.d("haris", "on Start")
    }

    override fun onResume() {
        super.onResume()
        Log.d("haris", "on Resume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("haris", "on Pause")
    }


    override fun onStop() {
        super.onStop()
        Log.d("haris", "on Stop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("haris", "on Destory")
    }


}