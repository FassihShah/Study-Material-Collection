package com.example.bsef22app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        if (savedInstanceState == null) {
            val fragment = BlankFragment()

            // Get the FragmentManager and start a transaction
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, fragment) // R.id.fragment_container is a FrameLayout
                .commit()
        }






    }



    override fun onRestart() {
        super.onRestart()
        Log.d("haris", "on Restart")
    }

    override fun onStart() {
        super.onStart()

        Log.d("haris", "on Start")
    }

    override fun onResume() {
        super.onResume()
        Log.d("haris", "on Resume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("haris", "on Pause")
    }


    override fun onStop() {
        super.onStop()
        Log.d("haris", "on Stop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("haris", "on Destory")
    }


}