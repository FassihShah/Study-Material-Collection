package com.example.bsef22app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.mainTextView)
        textView.text = "I've changed textview"

        val pressButton = findViewById<Button>(R.id.pressButton)
        pressButton.setOnClickListener {
            textView.text = "Value changed from button"
        }

        Log.d("haris", "on Create")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("haris", "on Restart")
    }

    override fun onStart() {
        super.onStart()

        Log.d("haris", "on Start")
    }

    override fun onResume() {
        super.onResume()
        Log.d("haris", "on Resume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("haris", "on Pause")
    }


    override fun onStop() {
        super.onStop()
        Log.d("haris", "on Stop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("haris", "on Destory")
    }


}