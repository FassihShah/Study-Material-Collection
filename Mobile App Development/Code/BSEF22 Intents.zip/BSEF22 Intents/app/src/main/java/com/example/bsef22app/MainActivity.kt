package com.example.bsef22app

import android.content.Intent
import android.content.Intent.ACTION_SEND
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
//            val intent = Intent(Intent.ACTION_SEND).apply {
//                type = "message/rfc822" // Ensures only email clients handle it
//                putExtra(Intent.EXTRA_EMAIL, arrayOf("recipient@example.com"))
//                putExtra(Intent.EXTRA_SUBJECT, "Subject here")
//                putExtra(Intent.EXTRA_TEXT, "Hello, this is a sample email!")
//            }

            startActivity(Intent.createChooser(intent, "Choose an email client"))
//            val intent = Intent(this, SecondActivity::class.java)
//            startActivity(intent)

//            val intent = Intent(ACTION_SEND)
//            intent.type = "text/plain"
//            intent.putExtra(Intent.EXTRA_EMAIL,"myemail")
//            startActivity(intent)
        }

//        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
//
//        recyclerView.adapter = UserAdapter(loadUsers()){ user: User ->
//            Log.d("haris", "user " + user.name + " pressed")
//        }
//        recyclerView.layoutManager = GridLayoutManager(this, 2)




    }

    private fun loadUsers(): List<User> {
        // In a real app, you might load from database or network
        return listOf(
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com"),
            User(name = "John Doe", email = "john@example.com"),
            User(name = "Jane Smith", email = "jane@example.com"),
            User(name = "Robert Johnson", email = "robert@example.com")
        )
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("haris", "on Restart")
    }

    override fun onStart() {
        super.onStart()

        Log.d("haris", "on Start")
    }

    override fun onResume() {
        super.onResume()
        Log.d("haris", "on Resume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("haris", "on Pause")
    }


    override fun onStop() {
        super.onStop()
        Log.d("haris", "on Stop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("haris", "on Destory")
    }


}